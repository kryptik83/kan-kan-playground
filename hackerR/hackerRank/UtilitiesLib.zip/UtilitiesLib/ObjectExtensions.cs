﻿using System.Reflection;
using Newtonsoft.Json.Linq;
using UtilitiesLib.Entities;

namespace UtilitiesLib
{
    public static class ObjectExtensions
    {
        public static object? GetPropertyValue(this object? @object, string propertyName)
        {
            if (@object == null) return null;

            var type = @object.GetType();
            IList<PropertyInfo> propertyInfos = new List<PropertyInfo>(type.GetProperties());

            return propertyInfos.Where(i => i.Name.Equals(propertyName, StringComparison.InvariantCultureIgnoreCase))
                .Select(info => info.GetValue(@object, null))
                .FirstOrDefault();
        }

        public static IEnumerable<ModifiedProperty> GetModifiedProperties(this object original, object objectWithChanges, string propNamePrefix = null)
        {
            var typeOfOriginalObject = original.GetType();
            var typeOfNewObject = objectWithChanges.GetType();

            if (typeOfOriginalObject != typeOfNewObject)
                throw new InvalidOperationException($"Cannot compare objects of type {typeOfOriginalObject} with {typeOfNewObject}");

            var modifiedProperties = new List<ModifiedProperty>();
            foreach (var info in typeOfOriginalObject.GetProperties()
                         .ToList())
            {
                var value1 = original.GetPropertyValue(info.Name);
                var value2 = objectWithChanges.GetPropertyValue(info.Name);

                if (object.Equals(value1, value2)) continue;
                if (value1 != null && value2 != null && (value1.GetType()
                        .IsNested || value2.GetType()
                        .IsNested))
                    modifiedProperties.AddRange(value1.GetModifiedProperties(value2, propNamePrefix: info.Name));
                else
                    modifiedProperties.Add(new ModifiedProperty(propNamePrefix != null ? $"{propNamePrefix}.{info.Name}" : info.Name, value1, value2));
            }

            return modifiedProperties;
        }

        // public static IEnumerable<ModifiedProperty> GetModifiedProperties(this string originalJson, string modifiedJson)
        // {
        //     var json1 = JToken.Parse(originalJson);
        //     var json2 = JToken.Parse(modifiedJson);
        //
        //     foreach (var token in json1.Children())
        //     {
        //         //https://stackoverflow.com/questions/24876082/find-and-return-json-differences-using-newtonsoft-in-c
        //         if (token.Children().Any())
        //         {
        //             var mod = token.DeepClone().ToString() ?? string.Empty;
        //             var modifiedProperties2 = mod.GetModifiedProperties(originalJson);
        //         }
        //     }
        //     
        //     return new  ModifiedProperty[] { };
        // }

        public static IEnumerable<ModifiedProperty> GetModifiedJsonProperties(this string originalJson, string modifiedJsonWithChanges)
        {
            // convert JSON to object
            JObject xptJson = JObject.Parse(modifiedJsonWithChanges);
            JObject actualJson = JObject.Parse(originalJson);

            // read properties
            var xptProps = xptJson.Properties()
                .ToList();
            var actProps = actualJson.Properties()
                .ToList();

            // find differing properties
            var auditLog = from existingProp in actProps
                from modifiedProp in xptProps
                where modifiedProp.Path.Equals(existingProp.Path)
                where !modifiedProp.Value.ToString().Equals(existingProp.Value.ToString())
                select new ModifiedProperty(PropertyName: existingProp.Path, OriginalValue: existingProp.Value.ToString(), ModifiedValue: modifiedProp.Value.ToString());

            return auditLog.ToHashSet();
        }
    }
}