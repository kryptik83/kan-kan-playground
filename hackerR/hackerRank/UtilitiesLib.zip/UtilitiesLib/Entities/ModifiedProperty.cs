namespace UtilitiesLib.Entities;

public record ModifiedProperty(string PropertyName, object? OriginalValue, object? ModifiedValue);